package practica1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Funxb
 */
public class Cuenta {
    private String nomCliente;
    private String numCuenta;
    private double tipoInteres;
    private double saldo;
    
    public Cuenta() {
    }
    
    public Cuenta(String nomCliente, String numCuenta, double tipoInteres, double saldo) {
        this.nomCliente=nomCliente;
        this.numCuenta=numCuenta;
        this.tipoInteres=tipoInteres;
        this.saldo=saldo;
    }

    public Cuenta(Cuenta Copia) {
        this.nomCliente=Copia.nomCliente;
        this.numCuenta=Copia.numCuenta;
        this.tipoInteres=Copia.tipoInteres;
        this.saldo=Copia.saldo;
    }
    
    public boolean deposito(double cantidad) {
        boolean depositoDone = true;
        if (cantidad < 0) {
            depositoDone = false;
        }
        else {
            this.saldo = this.saldo + cantidad;
        }
        
        return depositoDone; 
    }
    
    public boolean retiro(double cantidad) {
        boolean retiroDone = true;
        if (cantidad < 0) {
            retiroDone = false;
        }
        else {
            if (this.saldo - cantidad >=0) {
                this.saldo = this.saldo - cantidad;
            }
            else {
                retiroDone=false;
            }
        }
        return retiroDone; 
    }
    
    public boolean transferencia(Cuenta Destino, double importe) {
       
       boolean transferenciaExitosa = true;
       
       transferenciaExitosa = this.retiro(importe);
           if(transferenciaExitosa == true) {
               Destino.deposito(importe);
           }
        
        return transferenciaExitosa;
    }
    /**
     * @return the nomCliente
     */
    public String getNomCliente() {
        return nomCliente;
    }

    /**
     * @param nomCliente the nomCliente to set
     */
    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    /**
     * @return the numCuenta
     */
    public String getNumCuenta() {
        return numCuenta;
    }

    /**
     * @param numCuenta the numCuenta to set
     */
    public void setNumCuenta(String numCuenta) {
        this.numCuenta = numCuenta;
    }

    /**
     * @return the tipoInteres
     */
    public double getTipoInteres() {
        return tipoInteres;
    }

    /**
     * @param tipoInteres the tipoInteres to set
     */
    public void setTipoInteres(double tipoInteres) {
        this.tipoInteres = tipoInteres;
    }

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}
