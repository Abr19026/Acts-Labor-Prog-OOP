
package practica1;
import java.util.Scanner;

/**
 * @author Abraham Ramírez Moreno
 * 1902627
 */
public class Practica1 {

    public static void main(String[] args) {
        Scanner Scan = new Scanner(System.in);
        String nombreCliente = "_";
        String numeroCuenta = "_";
        double tipoInteres = 0;
        double saldo = 0;
        boolean opExitosa=true;
        
        //Pide datos cuenta 1
        System.out.println("\n---Datos cuenta 1---");
        System.out.println("\nNombre del cliente: ");
        nombreCliente = Scan.nextLine();
        System.out.println("\nNumero de cuenta: ");
        numeroCuenta = Scan.nextLine();
        System.out.println("\nTipo de interés: ");
        tipoInteres = Scan.nextDouble();
        System.out.println("\nSaldo de la cuenta: ");
        saldo = Scan.nextDouble();
        
        //Crea cuenta 1 con los datos dados
        Cuenta Cuenta1 = new Cuenta(nombreCliente, numeroCuenta, tipoInteres, saldo);
        
        Scan.nextLine(); //Limpia buffer de entrada
        
        //Pide datos cuenta 2
        System.out.println("\n---Datos cuenta 2---");
        System.out.println("\nNombre del cliente: ");
        nombreCliente = Scan.nextLine();
        System.out.println("\nNumero de cuenta: ");
        numeroCuenta = Scan.nextLine();
        System.out.println("\nTipo de interés: ");
        tipoInteres = Scan.nextDouble();
        System.out.println("\nSaldo de la cuenta: ");
        saldo = Scan.nextDouble();
        
        //Crea cuenta 2 con los datos dados
        Cuenta Cuenta2 = new Cuenta(nombreCliente, numeroCuenta, tipoInteres, saldo);
        
        //Operaciones son las cuentas
        System.out.println("\n---Operaciones---");
        
        //Retiro de dinero a cuenta 1
        System.out.println("\nCuanto dinero quiere retirar de la cuenta 1?: ");
        opExitosa = Cuenta1.retiro(Scan.nextDouble());
        if(opExitosa == true) {
            System.out.println("\nOperacion Exitosa,");
            System.out.printf("\nSaldo cuenta 1 es: $ %f",Cuenta1.getSaldo());
        }
        else {
            System.out.println("\nOperacion no se pudo realizar ");
        }
        
        //Deposito de dinero a cuenta 1
        System.out.println("\nCuanto dinero quiere depositar a la cuenta 1?: ");
        opExitosa = Cuenta1.deposito(Scan.nextDouble());
        if(opExitosa == true) {
            System.out.println("\nOperacion Exitosa ");
            System.out.printf("\nSaldo cuenta 1 es: $ %f",Cuenta1.getSaldo());

        }
        else {
            System.out.println("\nOperacion no se pudo realizar ");
        }
        
        //Retiro de dinero a cuenta 2
        System.out.println("\nCuanto dinero quiere retirar de la cuenta 2?: ");
        opExitosa = Cuenta2.retiro(Scan.nextDouble());
        if(opExitosa == true) {
            System.out.println("\nOperacion Exitosa ");
            System.out.printf("\nSaldo cuenta 2 es: $ %f",Cuenta2.getSaldo());
        }
        else {
            System.out.println("\nOperacion no se pudo realizar ");
        }
        
        //Deposito de dinero a cuenta 2
        System.out.println("\nCuanto dinero quiere depositar a la cuenta 2?: ");
        opExitosa = Cuenta2.deposito(Scan.nextDouble());
        if(opExitosa == true) {
            System.out.println("\nOperacion Exitosa ");
            System.out.printf("\nSaldo cuenta 2 es: $ %f",Cuenta2.getSaldo());
        }
        else {
            System.out.println("\nOperacion no se pudo realizar ");
        }
        
        //Transferencia de dinero de cuenta 1 a cuenta 2
        System.out.println("\nTransferencia: Cuanto dinero quiere transferir de cuenta 1 a cuenta 2?: ");
        opExitosa = Cuenta1.transferencia(Cuenta2, Scan.nextDouble());
        if(opExitosa == true) {
            System.out.println("\nOperacion Exitosa ");
            System.out.printf("\nSaldo cuenta 1 es: $ %f",Cuenta1.getSaldo());
            System.out.printf("\nSaldo cuenta 2 es: $ %f",Cuenta2.getSaldo());
        }
        else {
            System.out.println("\nOperacion no se pudo realizar ");
        }
        
        //Transferencia de dinero de cuenta 2 a cuenta 1
        System.out.println("\nTransferencia: Cuanto dinero quiere transferir de cuenta 2 a cuenta 1?: ");
        opExitosa = Cuenta2.transferencia(Cuenta1, Scan.nextDouble());
        if(opExitosa == true) {
            System.out.println("\nOperacion Exitosa ");
            System.out.printf("\nSaldo cuenta 2 es: $ %f",Cuenta2.getSaldo());
            System.out.printf("\nSaldo cuenta 1 es: $ %f",Cuenta1.getSaldo());
        }
        else {
            System.out.println("\nOperacion no se pudo realizar ");
        }
    }
    
}
