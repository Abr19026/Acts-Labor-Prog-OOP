/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act2lab;

/**
 *
 * @author Funxb
 */
public class Perro extends Animal{
    String color;
    boolean esDomestico;
    
    
    public String oler() {
        return "Perro oliendo";
    }
    
    public String Oir() {
        return "Perro oyendo";
    }
    
    public String ladrar() {
        return "Perro ladrando";
    }
    
    public String caminar() {
        return "Perro caminando";
    } 
}
