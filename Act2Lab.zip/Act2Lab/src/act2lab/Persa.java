/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act2lab;

/**
 *
 * @author Funxb
 */
public class Persa extends Gato{
    
    boolean cabelloLargo;
    
    public String escupirPelo() {
        if(!cabelloLargo) {
            return "Gato escupiendo pelo";
        }
        else {
            return "Gato escupiendo mucho pelo";
        }
        
    }
    
    Persa(boolean esMacho, String nombre, int edad, boolean ojosBicolor, boolean esDomestico, boolean cabelloLargo) {
        this.esCarnivoro = true;
        this.esDomestico = esDomestico;
        this.esMacho = esMacho;
        this.nombre = nombre;
        this.edad = edad;
        this.ojosBicolor = ojosBicolor;
        this.cabelloLargo = cabelloLargo;
    }
    
    @Override
    public String toString() { 
        String resultado, sexo="Hembra", bicolor="No", esdomestico="No", cabello="Corto", dieta="Herbivoro";
        if(esMacho)
            sexo= "Macho";
        
        if(ojosBicolor)
            bicolor="Sí";
        
        if(esDomestico)
            esdomestico="Sí";
                    
        if(cabelloLargo)
            cabello = "Largo";
        
        if(esCarnivoro)
            dieta="Carnivoro";
        
        
        resultado = "\nGATO PERSA\nNombre: " + this.nombre + "\nEdad: " + this.edad + "\nSexo: " + sexo + 
                "\nDieta: " + dieta + "\nOjos bicolor: " + bicolor + "\nDomestico: " + esdomestico + "\nCabello: " + cabello; 
        return resultado;
    }
    
    
}
