/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act2lab;

/**
 *
 * @author Funxb
 */
public class Perico extends Ave{
    
    public String decir(String mensaje) {
        return "Perico dice " + mensaje;
    }
    
    Perico(boolean esMacho, String nombre, int edad, String color) {
        this.esCarnivoro = false;
        this.esMacho = esMacho;
        this.nombre = nombre;
        this.edad = edad;
        this.color = color;
    }
    
    @Override
    public String toString() { 
        String resultado, sexo="Hembra", dieta="Herbivoro";
        if(esMacho)
            sexo= "Macho";
        
        if(esCarnivoro)
            dieta="Carnivoro";
        
        resultado = "\nAVE PERICO\nNombre: " + this.nombre + "\nEdad: " + this.edad + "\nSexo: " + sexo + 
                "\nDieta: " + dieta + "\nColor: " + this.color;
        return resultado;
    }
}
