/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act2lab;
import java.util.Scanner;

/**
 *
 * @author Funxb
 */
public class Act2Lab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner Scn = new Scanner(System.in);
        
        //Crea Chihuahua
        Chihuahua Ch1= new Chihuahua(true,"Perrin",4,"Café");
        System.out.println(Ch1.toString());
        System.out.println(Ch1.comer());
        System.out.println(Ch1.dormir());
        System.out.println(Ch1.oler());
        System.out.println(Ch1.Oir());
        System.out.println(Ch1.ladrar());
        System.out.println(Ch1.caminar());
        
        //Crea Pastor
        PastorAleman PaAl= new PastorAleman(false,"Marisa",5,"Café",true,true);
        System.out.println(PaAl.toString());
        System.out.println(PaAl.comer());
        System.out.println(PaAl.dormir());
        System.out.println(PaAl.oler());
        System.out.println(PaAl.Oir());
        System.out.println(PaAl.ladrar());
        System.out.println(PaAl.caminar());
        
        //Crea Perico
        Perico Per1 = new Perico(true,"Cocorrín",7,"verde");
        System.out.println(Per1.toString());
        System.out.println(Per1.comer());
        System.out.println(Per1.dormir());
        System.out.println(Per1.volar());
        System.out.println(Per1.ponerHuevo());
        System.out.println(Per1.decir("Hola me llamo cocorrín"));
        //Crea Canario
        Canario Can = new Canario(false,"Pinto", 1,"rojo");
        System.out.println(Can.toString());
        System.out.println(Can.comer());
        System.out.println(Can.dormir());
        System.out.println(Can.volar());
        System.out.println(Can.ponerHuevo());
        System.out.println(Can.cantar());
        
        //Crea Siames
        Siames Si1 = new Siames(true, "Pedro", 4,true,true,false);
        System.out.println(Si1.toString());
        System.out.println(Si1.comer());
        System.out.println(Si1.dormir());
        System.out.println(Si1.brincar());
        System.out.println(Si1.maullar());
        System.out.println(Si1.observar());
        System.out.println(Si1.cazar());
        System.out.println(Si1.acurrucarse());
        System.out.println(Si1.jugarCon());
        
        //Crea Persa
        Persa Pe1 = new Persa(false,"Tito", 4, false,true,true);
        System.out.println(Pe1.toString());
        System.out.println(Pe1.comer());
        System.out.println(Pe1.dormir());
        System.out.println(Pe1.brincar());
        System.out.println(Pe1.maullar());
        System.out.println(Pe1.observar());
        System.out.println(Pe1.cazar());
        System.out.println(Pe1.escupirPelo());
        
    }
    
}
