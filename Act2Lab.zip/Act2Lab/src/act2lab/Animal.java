/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act2lab;

/**
 *
 * @author Funxb
 */
public class Animal {
    Boolean esMacho;
    Boolean esCarnivoro;
    String nombre;
    int edad;
    
    public String comer() {
        return "Animal comiendo";
    }
    
    public String dormir() {
        return "Animal durmiendo";
    }
}
