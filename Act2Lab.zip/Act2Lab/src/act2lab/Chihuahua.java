/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act2lab;

/**
 *
 * @author Funxb
 */
public class Chihuahua extends Perro{
    
    
    public String correr() {
        return "Corriendo a 10km/h";
    }
    
    public String temblar() {
        return "Perro temblando";
    }
    
    Chihuahua(boolean esMacho, String nombre, int edad, String color) {
        this.esCarnivoro = true;
        this.esDomestico = true;
        this.esMacho = esMacho;
        this.nombre = nombre;
        this.edad = edad;
        this.color = color;
    }
    
    @Override
    public String toString() { 
        String resultado, sexo="Hembra", esdomestico="No", cabello="Corto", dieta="Herbivoro";
        if(esMacho)
            sexo= "Macho";
        
        if(esDomestico)
            esdomestico="Sí";
        
        if(esCarnivoro)
            dieta="Carnivoro";
        
        
        resultado = "\nPERRO CHIHUAHUA\nNombre: " + this.nombre + "\nEdad: " + this.edad + "\nSexo: " + sexo + 
                "\nDieta: " + dieta + "\nColor: " + this.color + "\nDomestico: " + esdomestico;
        return resultado;
    }
}
