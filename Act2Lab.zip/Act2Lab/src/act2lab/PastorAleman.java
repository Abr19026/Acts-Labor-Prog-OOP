/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act2lab;

/**
 *
 * @author Funxb
 */
public class PastorAleman extends Perro{
    
    Boolean esPolicia;
    
    public String rastrear(String objetivo) {
        return "Perro rastreando " + objetivo;
    }
    
    public String vigilar () {
        return "Perro vigilando";
    }
    
    public String correr () {
        return "Perro corriendo a 25km/h";
    }
    
    PastorAleman(boolean esMacho, String nombre, int edad, String color, boolean esDomestico, boolean esPolicia) {
        this.esCarnivoro = true;
        this.esDomestico = esDomestico;
        this.esPolicia = esPolicia;
        this.esMacho = esMacho;
        this.nombre = nombre;
        this.edad = edad;
        this.color = color;
    }
    
    @Override
    public String toString() { 
        String resultado, sexo="Hembra", esdomestico="No", cabello="Corto", dieta="Herbivoro", policia = "No";
        if(esMacho)
            sexo= "Macho";
        
        if(esDomestico)
            esdomestico="Sí";
        
        if(esCarnivoro)
            dieta="Carnivoro";
        
        if(esPolicia)
            policia = "Sí";
        
        resultado = "\nPERRO PASTOR ALEMAN\nNombre: " + this.nombre + "\nEdad: " + this.edad + "\nSexo: " + sexo + 
                "\nDieta: " + dieta + "\nColor: " + this.color + "\nDomestico: " + esdomestico + "\nEs policia: " + policia;
        return resultado;
    }
}
