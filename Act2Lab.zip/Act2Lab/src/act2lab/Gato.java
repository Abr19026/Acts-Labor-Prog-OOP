/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act2lab;

/**
 *
 * @author Funxb
 */
public class Gato extends Animal{
    
    boolean ojosBicolor;
    boolean esDomestico;
    
    public String brincar() {
        return "Gato brincando";
    }
    
    public String maullar() {
        return "Gato maullando";
    }
    
    public String observar() {
        return "Gato observando";
    }
    
    public String cazar() {
        return "Gato cazando";
    }
}
