/*
1.Funcion convertir int to string
2.Función suma n números
3. Generar X numeros random y contar cuantos números termina por el numero x

4. Programa Java que muestre los números del 1 al 100 utilizando la instrucción while
5. Programa Java que muestre los números del 1 al 100 utilizando la instrucción do..while
6. Programa Java que muestre los números del 1 al 100 utilizando la instrucción for 
7. Convertir a números romanos – Diccionario de datos

*/
package actividad12.funciones;
import java.util.ArrayList;
import java.util.Random;
import java.util.Hashtable;
/**
 *
 * @author Usuario
 */
public class Funciones {
    /*INT A STRING Y VICEVERSA*/
    public String intString(int numero) {
        return Integer.toString(numero);
    }
    
    public int intString(String numero) {
        return Integer.parseInt(numero);
    }
    
    /*Suma de n numeros*/ 
    public double sumar(String numeros) {
        String[] lista = numeros.split(",");
        double suma = 0;
        
        for(String numero : lista) {
            suma += Double.valueOf(numero);
        }
        return suma;
    }
    /*X numeros aleatorios, cuantos terminan con y*/
    public int cuantosRandom(int cantidad,int terminacion) {
        int i=0;
        int cumplen = 0;
        int random;
        Random gen = new Random();
        System.out.println("\n");
        while(i<cantidad) {
            random = gen.nextInt(terminacion*10);
            System.out.print(random + ",");
            if(terminaCon(random,terminacion)) {
                cumplen++;
            }
            i++;
        }
        return cumplen;
    }
    
    public boolean terminaCon(int numero,int terminacion) {
        String fin = intString(terminacion);
        String checar = intString(numero);
        return checar.endsWith(fin);
    }
    /*Muestra los numeros del x al y con while*/
    
    public void cuentaWhile(int desde,int hasta) {
        
        int direccion = 1;
        if(desde>hasta) {
            direccion = -1;
        }
        
        while(desde != hasta + direccion) {
            System.out.print(desde + ",");
            desde+=direccion;
        }
    }
    /*Muestra los numeros del x al y con do while*/
    public void cuentaDoWhile(int desde,int hasta) {
        
        int direccion = 1;
        if(desde>hasta) {
            direccion = -1;   
        }
        
        do {
            System.out.print(desde + ",");
            desde+=direccion;
        } while(desde != hasta + direccion);
    }
    /*Muestra los numeros del x al y con for*/
    public void cuentaFor(int desde,int hasta) {
        
        int direccion = 1;
        if(desde>hasta) {
            direccion = -1;   
        }
        
        for(int i=desde; i!=hasta+direccion; i+=direccion) {
            System.out.print(i + ",");
        }
    }
   /* Convertir a números romanos – Diccionario de datos */
    
    public String aRomano(int entrada) {        
        //Creación
        
        //Romano a construir
        StringBuilder romano = new StringBuilder("");
        
        //Entrada en chars
        char[] enCars = intString(entrada).toCharArray(); 
        
        int pos= enCars.length - 1;
        
        //Lee desde potencia 0 de 10 hasta potencia 3
        for(char digito : enCars) {
            int a = Character.getNumericValue(digito);
            romano.append(romanoPos(a,pos));
            pos--;
        }
        
        return romano.toString();
    }
    
    public String romanoPos(int entrada, int potencia) {
        //Tablas de datos
        Hashtable <Integer,String> pos = new Hashtable <Integer,String>();
        Hashtable<Integer,String> mult = new Hashtable <Integer,String>() ;
        
        pos.put(0,"I");
        pos.put(1,"X");
        pos.put(2, "C");
        pos.put(3, "M");
        
        mult.put(0,"V");
        mult.put(1,"L");
        mult.put(2, "D");
        
        StringBuilder digitos = new StringBuilder("");
        
        switch(entrada) {
            case 1:case 2:case 3:
                for(int i=0;i<entrada;i++) {
                    digitos.append(pos.get(potencia));
                }
                break;
            case 4:
                digitos.append(pos.get(potencia));
                digitos.append(mult.get(potencia));
                break;
            case 5:
                digitos.append(mult.get(potencia));
                break;
            case 6:case 7:case 8:
                digitos.append(mult.get(potencia));
                for(int i=0;i<entrada-5;i++) {
                    digitos.append(pos.get(potencia));
                }
                break;
            case 9:
                digitos.append(pos.get(potencia));
                digitos.append(pos.get(potencia + 1));
                break;
        }
        return digitos.toString();
    }
}
