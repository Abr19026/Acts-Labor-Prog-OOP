/*
1.Funcion convertir int to string
2.Función suma n números
3. Generar X numeros random y contar cuantos números termina por el numero x

4. Programa Java que muestre los números del 1 al 100 utilizando la instrucción while
5. Programa Java que muestre los números del 1 al 100 utilizando la instrucción do..while
6. Programa Java que muestre los números del 1 al 100 utilizando la instrucción for 
7. Convertir a números romanos – Diccionario de datos*/
package actividad12.funciones;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Actividad12Funciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Funciones f = new Funciones();
        Scanner lee = new Scanner(System.in);
        String entrada;
        int cant;
        int cant2;
        int cant3;
        //Programa 2
/*
        System.out.println("\nEscriba numeros separados por comas\n");
        entrada = lee.nextLine();
        System.out.println("Suma: " + f.sumar(entrada));
*/
        //Programa 3
/*
        System.out.println("\nEscriba cuantos numeros al azar quiere hallar\n");
        cant = lee.nextInt();
        lee.nextLine();
        System.out.println("\nEscriba que terminación quiere hallar\n");
        cant2 = lee.nextInt();
        lee.nextLine();
        System.out.println("Numeros generados");
        cant3 = f.cuantosRandom(cant, cant2);
        System.out.println("\nSe generaron " + cant3 + " numeros que terminan con " + cant2);
*/
        //Programa 4 5 y 6
        /*
        System.out.println("Introduzca numero desde el que quiere contar: ");
        cant = lee.nextInt();
        lee.nextLine();
        System.out.println("\nEscriba hasta que numero quiere contar4");
        cant2 = lee.nextInt();
        lee.nextLine();
        System.out.println("\nCuenta con while: ");
        f.cuentaWhile(cant, cant2);
        System.out.println("\nCuenta con dowhile: ");
        f.cuentaDoWhile(cant, cant2);
        System.out.println("\nCuenta con for: ");
        f.cuentaFor(cant, cant2);
        */
        //Programa 7
        System.out.println("Escriba numero que debe convertir a romano (menor a 4000)");
        cant = lee.nextInt();
        lee.nextLine();
        System.out.println(f.aRomano(cant));
    }
    
}
