/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LeeEscribe;
import java.io.File;
import java.beans.XMLEncoder;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * @author Usuario
 */
public class Escribir {
    
    public int write(File destino, Object objeto) {
        try (FileOutputStream fos = new FileOutputStream(destino)) {
            try(XMLEncoder encoder = new XMLEncoder(fos)) {
                encoder.writeObject(objeto);
                return 0;
            }
        }
        catch(IOException ex) {
            return 1;
        }
    }
    
}
