/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LeeEscribe;
import java.io.File;
import java.beans.XMLDecoder;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author Usuario
 */
public class Leer {
    public <T> T read(File entrada) {
        try (FileInputStream fis = new FileInputStream(entrada)) {
            try(XMLDecoder decoder = new XMLDecoder(fis)) {
                T salida;
                salida = (T) decoder.readObject();
                return salida;
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Error FNF");
            return null;
        } catch (IOException ex) {
            System.out.println("Error IOE");
            return null;
        }
    }
}
