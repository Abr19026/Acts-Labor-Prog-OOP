/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usandolibreria;
import LeeEscribe.Escribir;
import LeeEscribe.Leer;
import java.util.Scanner;
import java.io.File;
/**
 *
 * @author Usuario
 */
public class UsandoLibreria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        File guardar = new File("Objeto.xml");
        Scanner scan = new Scanner(System.in);
        Escribir escritor = new Escribir();
        Leer lector = new Leer();
        int opcion;
        System.out.println("1-Guardar Texto 2-Recuperar texto");
        opcion=scan.nextInt();
        scan.nextLine();
        switch(opcion) {
            case 1:
                String entradaUsuario;
                System.out.println("Introduzca texto: ");
                entradaUsuario = scan.nextLine();
                escritor.write(guardar, entradaUsuario);
                break;
            case 2:
                String lecturaArchivo;
                System.out.println("Texto leido: ");
                lecturaArchivo = lector.read(guardar);
                System.out.println(lecturaArchivo);
                break;
            default: System.out.println("No valido");
        }
    }
    
}
