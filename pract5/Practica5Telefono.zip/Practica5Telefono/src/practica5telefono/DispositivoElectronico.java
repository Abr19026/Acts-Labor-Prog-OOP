/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica5telefono;

/**
 *
 * @author Funxb
 */
public abstract class DispositivoElectronico {
    protected boolean encendido;
    private String marca;
    private String modelo;
    
    
    public abstract void encender();
    public abstract String apagar();
    
    public String getMarca() {
        return marca;
    }

    protected void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }
    
    protected void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    public boolean isEncendido() {
        return encendido;
    }
}
