/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica5telefono;

import java.util.Scanner;

public class Telefono extends DispositivoElectronico implements IWifiConeccion{
    private boolean conectadoWifi;
    private double precio;
    private String color; 
    Contacto[] listaContactos = new Contacto[5];
    
    Scanner scan = new Scanner(System.in);
    
    public void correr(){
        int opcion;
        while(isEncendido()){
            System.out.println("\n\nCELULAR " + this.getMarca()+ " " + this.getModelo());
            mostrarConeccion();
            System.out.println("1- Llamada");
            System.out.println("2- Nuevo contacto");
            System.out.println("3- Lista de contactos");
            System.out.println("4- Conectar a Wifi");
            System.out.println("5- Desconectar de Wifi");
            System.out.println("6- Salir");
            
            do {
                System.out.println("Opcion a escoger: ");
                opcion = scan.nextInt();
                scan.nextLine();
            }while(opcion>6||opcion<1);
            
            switch(opcion) {
                case 1:
                    menuLlamadas();
                    break;
                case 2:
                    if(cantContactos()>=5)
                        System.out.println("Lista de contactos llena");
                    else {
                        listaContactos[cantContactos()] = nuevoContacto();
                    }
                    break;
                case 3:
                    System.out.println(listarContactos());
                    break;
                case 4:
                    System.out.println("RED WIFI");
                    System.out.println("Introduzca contraseña de red: ");
                    setPassword(scan.nextLine());
                    break;
                case 5:
                    this.conectadoWifi = false;
                    break;
                case 6:
                    System.out.println(this.apagar());
            }
        }
        System.out.println("Telefono apagado");
    }
    
    private int iniciarLlamada(int numero) {
        System.out.println("Llamando a: " + numero);
        System.out.println(finalizarLlamada());
        return numero;
    }
    
    private String iniciarLlamada(Contacto contacto) {
        System.out.println("Llamando a: " + contacto.getNom() + " - " + contacto.getTel());
        System.out.println(finalizarLlamada());
        return contacto.getNom() + contacto.getTel();
    }
    
    private String finalizarLlamada() {
        System.out.println("Presione enter para colgar ");
        scan.nextLine();
        return "Colgando";
    }
    
    private Contacto nuevoContacto() {
        String nombre, telefono, correo;
        Contacto nuevo;
        
        System.out.println("Nombre: ");
        nombre = scan.nextLine();
        System.out.println("Telefono: ");
        telefono = scan.nextLine();
        System.out.println("Correo: ");
        correo = scan.nextLine();
        nuevo = new Contacto(nombre,telefono,correo);
        return nuevo;
    }
    
    private String listarContactos() {
        int i=0;
        String contactos = "CONTACTOS\n";
        for(Contacto ele : listaContactos) {
            if(ele!=null) {
                contactos = contactos + "\n"+ (i+1) + ") Nombre: " + ele.getNom() + " - Telefono: " +
                            ele.getTel() + " - Correo: " + ele.getMail();
                i++;
            }
        }
        return contactos;
    }

    private int cantContactos() {
        int cantidad=0;
        for(Contacto ele : listaContactos) {
            if(ele!=null) {
                cantidad++;
            }
        }
        return cantidad;
    }
    
    private void menuLlamadas() {
        int opcion,opcion2;
        int numero;
        System.out.println("LLAMADAS");
        System.out.println("1- LLamar a contacto");
        System.out.println("2- Llamar a numero");
        do {
                System.out.println("Opcion a escoger: ");
                opcion = scan.nextInt();
                scan.nextLine();
        }while(opcion!=1&&opcion!=2);
        
        switch(opcion) {
            case 1:
                if(cantContactos()>0) {
                    System.out.println(listarContactos());
                    do
                    {
                        System.out.println("Contacto a llamar");
                        opcion2 = scan.nextInt();
                        scan.nextLine();
                    }while(opcion2<1 || opcion2 > cantContactos());
                    
                    iniciarLlamada(listaContactos[opcion2-1]);
                }
                else
                    System.out.println("No hay contactos");
                break;
            case 2:
                System.out.println("Numero: ");
                numero = scan.nextInt();
                scan.nextLine();
                iniciarLlamada(numero);
                break;
            
        }
    }
    
    private void mostrarConeccion() {
        if(isConnected()) {
            System.out.println("Conectado al WIFI");
        }
        else {
            System.out.println("No conectado");
        }
    }
    
    @Override
    public void encender() {
        this.encendido = true;
    }

    @Override
    public String apagar() {
        this.encendido = false;
        return "Apagando telefono";
    }

    @Override
    public boolean isConnected() {
        return this.conectadoWifi;
    }

    @Override
    public void setPassword(String Password) {
        this.conectadoWifi = true;
        System.out.println("Conectado a la red"); 
    }

    Telefono(String marca, String modelo, String color, double precio) {
        this.setMarca(marca);
        this.setModelo(modelo);
        this.color = color;
        this.precio = precio;
        this.conectadoWifi=false;
        this.encendido = false;
    }

  
    public double getPrecio() {
        return precio;
    }

    public String getColor() {
        return color;
    }
}
