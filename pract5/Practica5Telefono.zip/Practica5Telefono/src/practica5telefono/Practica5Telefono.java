/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica5telefono;
import java.util.Scanner;
/**
 *
 * @author Funxb
 */
public class Practica5Telefono {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String marca, modelo,color;
        double precio;
        
        Telefono[] telefonos = new Telefono[5];
        for(int i=0;i<5;i++) {
            //Lecturas de datos
            System.out.println("\n\nNuevo Telefono");
            System.out.println("Marca del telefono: ");
            marca = scan.nextLine();
            System.out.println("Modelo del telefono: ");
            modelo = scan.nextLine();
            System.out.println("Color del telefono: ");
            color = scan.nextLine();
            System.out.print("Precio del telefono: $ ");
            precio = scan.nextInt();
            scan.nextLine();
            //Crea telefono
            telefonos[i] = new Telefono(marca,modelo,color,precio);
            //Enciende el telefono
            telefonos[i].encender();
            //Despliega un menú con las opciones
            telefonos[i].correr();
        }  
    }
}
