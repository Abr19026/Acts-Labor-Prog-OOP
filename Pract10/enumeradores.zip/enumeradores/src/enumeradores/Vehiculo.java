/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enumeradores;


/**
 *
 * @author Usuario
 */
public class Vehiculo {
    
    private String matricula;
    private MarcaDeVehiculo marca;

    //Constructor
    
    public Vehiculo(MarcaDeVehiculo m) {
        this.marca = m;
        this.matricula = m.toString();
    } 
    
    //GETTERS Y SETTERS
    /**
     * @return the matricula
     */
    public String getMatricula() {
        return matricula;
    }

    /**
     * @param matricula the matricula to set
     */
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    /**
     * @return the marca
     */
    public MarcaDeVehiculo getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(MarcaDeVehiculo marca) {
        this.marca = marca;
    }
}
