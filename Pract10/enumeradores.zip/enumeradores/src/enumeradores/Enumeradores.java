/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enumeradores;

/**
 *
 * @author Usuario
 */
public class Enumeradores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Vehiculo[] venta = new Vehiculo[3];
        venta[0] = new Vehiculo(MarcaDeVehiculo.TOYOTA);
        venta[1] = new Vehiculo(MarcaDeVehiculo.FORD);
        venta[2] = new Vehiculo(MarcaDeVehiculo.RENAULT);
        
        for(Vehiculo carro : venta) {
            switch(carro.getMarca()) {
                case FORD: case RENAULT: case SUZUKI:
                    System.out.println("Carro " + carro.getMatricula() + " es caro");
                    break;
                case TOYOTA: case SEAT:
                    System.out.println("Carro " + carro.getMatricula() + " es barato");
                    break;
            }
        }
    }
    
}
