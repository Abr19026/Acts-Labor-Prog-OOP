/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genericsfilesannotations;

/**
 *
 * @author Funxb
 */

@Deprecated
public class AutomovilViejo extends Automovil{
    
    public AutomovilViejo(String marca, String modelo, String precio, int gas) {
        super(marca, modelo, precio, gas);
    }
    
    @Override
    public String movimiento(String direccion) {
        
        if(direccion.equals("derecha")) {
            return "Volteando a la derecha";
        }
        else {
            throw new IllegalArgumentException("Direccion no valida");
        }
    }
    
}
