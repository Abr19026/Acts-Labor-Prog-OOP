/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genericsfilesannotations;

import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Funxb
 */
public class RUNprograma {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        LecturaArchivo arch = new LecturaArchivo();
        String archivo = "datos.csv";
        ArrayList<Automovil> carros = new ArrayList<>(10);
        String[] datos;
        Automovil aux;
        int i;
        
        for(i=0;i<10;i++) {
            datos = arch.LeerLinea(i,archivo);
            aux = new Automovil(datos[0],datos[1],datos[2],Integer.parseInt(datos[3]));
            carros.add(aux);
        }
        
        i=0;
        for(Automovil car : carros) {
            String dir = arch.LeerDireccion(i, archivo);
            System.out.println(car.StringPropiedades());
            System.out.println(car.movimiento(arch.LeerDireccion(i, archivo)));
            i++;
        }
    }
    
}
