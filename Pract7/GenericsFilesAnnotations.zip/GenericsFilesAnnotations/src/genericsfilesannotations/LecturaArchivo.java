/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genericsfilesannotations;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Funxb
 */
public class LecturaArchivo {
    @DocumentacionMiFuncion(
            entradas = "Un entero que indica el renglon del archivo empezando desde 0 y un string que indica direccion del archivo\n",
            retorno = "Un arreglo de Srings con los 4 primeros valores en ese renglón del archivo\n",
            precauciones = "Los valores en el archivo deben de estar separados por comas. "
                         + "Si no existe el renglón o el renglón no tiene al menos 4 elementos separados por comas lanza un IOException\n"
    )
    String[] LeerLinea(int linea,String archivo) throws FileNotFoundException, IOException {
        try(FileReader arch = new FileReader(archivo)) {
            
            String[] inicializa = new String[4];
            String auxiliar = "";
            int leido,renglon=0,dato=0;
            
            
            while(renglon != linea) {
                
                if( (leido = arch.read()) == (int)'\n') {
                    renglon++;
                }
                else if(leido==-1) {
                    throw new IOException("Archivo no alcanza hasta esa linea");
                }
                
            }
            
            while(dato<4) {
                
                leido = arch.read();
                
                if(leido == (int)',') {
                    inicializa[dato] = auxiliar;
                    dato++;
                    auxiliar = "";
                }
                else if((leido == (int)'\n') || (leido == -1) || leido == 13) {
                    if(dato!=3) {
                        throw new IOException("Archivo no tiene formato correcto");
                    }
                    else {
                        inicializa[dato] = auxiliar;
                        dato++;
                    }
                }
                else {
                    auxiliar = auxiliar + (char)leido;
                }
            }
            
            return inicializa;
        }
    }
    
    @DocumentacionMiFuncion(
            entradas = "Un entero que indica el renglon del archivo empezando desde 0 y un string que indica direccion del archivo\n",
            retorno = "El 5 elemento separado por comas en el renglon indicado del archivo\n",
            precauciones = "Los valores en el archivo deben de estar separados por comas. "
                         + "Si no existe el renglón o el renglón no tiene al menos 5 elementos separados por comas lanza un IOException\n"
    )
    String LeerDireccion(int linea, String archivo) throws FileNotFoundException, IOException {
        try(FileReader arch = new FileReader(archivo)) {
            
            String direccion = "";
            int leido,renglon=0,comas=0;
            boolean valido=true;
            
            while(renglon != linea) {
                
                if( (leido = arch.read()) == (int)'\n') {
                    renglon++;
                }
                else if(leido==-1) {
                    throw new IOException("Archivo no alcanza hasta esa linea");
                }
            }
            
            while(comas!=4) {
                leido = arch.read();
                if(leido==(int)',') {
                    comas++;
                } 
                else if((leido == (int)'\n') || (leido == -1)) {
                    throw new IOException("Archivo no tiene formato correcto");
                }
            }
            
            while(valido) {
                leido = arch.read();
                if(leido == -1 || leido == (int)'\n' || leido == 13 || leido == (int)',') {
                    valido = false;
                }
                else{
                    direccion = direccion + (char)leido;
                }
            }
            return direccion;
            
        }
    }
    
    
}
