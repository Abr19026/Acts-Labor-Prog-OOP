/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genericsfilesannotations;

/**
 *
 * @author Funxb
 */
public class Automovil {
    private String marca;
    private String modelo;
    private String precio;
    private int gasolina;
    
    @DocumentacionMiFuncion(
            entradas = "Litros de gasolina con que se inicializa el carro",
            precauciones = "Cantidad de gasolina debe ser mayor a 1, si no lanza excepciin de argumento ilegal"
    )
    private void encender(int gas) {
        if(gas<=1) {
            throw new IllegalArgumentException("Gasolina debe ser mayor a 1");
        }
        this.gasolina = gas;
    }
    
    public String alto() {
        return "Parando automovil";
    }
    
    @DocumentacionMiFuncion(
            entradas = "Un string que diga izquierda o derecha",
            retorno = "String que indica que el carro voltea a esa direccion",
            precauciones = "Si la entrada no es 'izquierda' o 'derecha' lanza una excepcion de argumento ilegal"
    )
    public String movimiento(String direccion) {
        
        if(direccion.equals("derecha")) {
            return "Volteando a la derecha";
        }
        else if(direccion.equals("izquierda")) {
            return "Volteando a la izquierda";
        }
        else {
            throw new IllegalArgumentException("Direccion no valida");
        }
    }
    
    @DocumentacionMiFuncion(
            retorno = "String que con propiedades marca, modelo y precio con formato"
    )
    public String StringPropiedades() {
        return "\nMarca: " + marca + "\nModelo: " + modelo + "\nprecio: $" + precio;
    }
    
    Automovil(String marca, String modelo, String precio, int gas) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        encender(gas);
    }
    
}
