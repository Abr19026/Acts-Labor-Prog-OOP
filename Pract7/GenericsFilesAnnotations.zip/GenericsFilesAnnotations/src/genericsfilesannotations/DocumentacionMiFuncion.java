/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genericsfilesannotations;

import java.lang.annotation.Documented;

/**
 *
 * @author Funxb
 */

@Documented
public @interface DocumentacionMiFuncion {
    String entradas() default "N/A";
    String retorno() default "N/A";
    String precauciones() default "N/A";
}
