/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4strings;

/**
 *
 * @author Funxb
 */
public class FuncionesString {
    //1- Dividir string entrada
    String[] dividir(String entrada) {
        return entrada.split("-");
    }
    //2
    boolean subcadenaFinal(String entrada, String termina) {

        if(entrada.endsWith(termina)) {
            return true;
        }
        return false;
    }
    //3 Commprueba si una cadena leída por teclado comienza por una subcadena introducida por teclado.
    boolean subcadenaInicial(String entrada, String empieza) {

        if(entrada.startsWith(empieza)) {
            return true;
        }
        return false;
    }
    //4 Pide una cadena y un carácter por teclado  y muestra cuantas veces aparece el carácter en la cadena. 
    int cantCaracter(String Cadena, char letra) {
        int cant = 0;
        for(char carac : Cadena.toCharArray()) {
            if(carac==letra) {
                cant++;
            }
        }
        return cant;
    }
    
    //5 Dada una cadena que representa una frase cuenta cuantas palabras tiene.
    int cantPalabras(String Cadena) {
        String[] Palabras = Cadena.split(" ");
        return Palabras.length;
    }
    //6 Dada una cadena con un nombre y apellidos, realizar un programa que muestre las iniciales en mayúsculas.
    String iniciales(String Nombre) {
        String[] Palabras = Nombre.split(" ");
        String inic = "";
        
        for(String pal : Palabras) {
            inic = inic + pal.charAt(0);
        }
        
        return inic.toUpperCase();
    }
    
    //7 dada una cadena de caracteres genere otra cadena resultado de invertir la primera.
    String invertir(String aInvert) {
        int leng = aInvert.length();
        char[] enChars = aInvert.toCharArray();
        String invert = "";
        for(int i = 0; i<leng; i++) {
            invert = invert + enChars[leng-i-1];
        }
        return invert;
    }
    
    //8 Dada una cadena y dos caracteres sustituye la aparición del primer carácter en la cadena por el segundo carácter. 
    String sustitCaracter(String cadena, char aSust, char sustCon) {
        int leng = cadena.length();
        char[] enChars = cadena.toCharArray();
        
        for(int i=0; i<leng; i++) {
            if(enChars[i] == aSust) {
                enChars[i] = sustCon; 
            }
        }
        return new String(enChars);
    }
    
    // 9 dada una cadena, convierte las mayúsculas a minúsculas y viceversa. 
    String invierteCase(String cadena) {
        int leng = cadena.length();
        char[] enChars = cadena.toCharArray();
        
        for(int i=0; i<leng; i++) {
            if(Character.isLowerCase(enChars[i])) {
                enChars[i] = Character.toUpperCase(enChars[i]); 
            }
            else {
                if(Character.isUpperCase(enChars[i])) {
                    enChars[i] = Character.toLowerCase(enChars[i]); 
                }
            }
        }
        return new String(enChars);
    }
    
    //10 Dada dos cadenas, checar si la primera contiene a la segunda.
    boolean subcadena(String contiene, String contenida) {
       char[] mas = contiene.toCharArray();
       char[] men = contenida.toCharArray();
       
       int maxle = contiene.length();
       int minle = contenida.length();
       
       if(minle>maxle) {
           return false;
       }
       
       for(int i=0;i<maxle;i++) {
           int desp = 0;
           while(mas[i+desp] == men[desp]) {
               desp++;
               if(desp == minle) {
                   return true;
               }
               if(desp+i>=maxle) {
                   return false;
               }
           }
       }
       return false;
    }
    //11 Dada cadena de caracteres indicar si es un palíndromo
    boolean esPalindromo(String cadena) {
        String invertida = invertir(cadena);
        if(invertida.equals(cadena)) {
            return true;
        }
        return false;
    }
    
}
