/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4strings;
import java.util.Scanner;
/**
 *
 * @author Funxb
 */
public class Practica4Strings {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        FuncionesString s = new FuncionesString();
        Scanner scan = new Scanner(System.in);
        String cad1;
        String cad2;
        String cad3;
        String[] res1;
        char[] aux;
        
        
        //1 programa pregunte por una cadena separada por guiones y que 
        //divida la cadena por medio de los guiones. Imprimir el resultado
        System.out.println("\n----1 Separa cadena en guiones----");
        System.out.println("\nCadena separada por guiones: ");
        cad1 = scan.nextLine();
        res1 = s.dividir(cad1);
        System.out.println("\nCadenas separadas:");
        for(String ele : res1) {
            System.out.println(ele);
        }

        //2 Indica si una cadena termina con otra
        System.out.println("\n----2 Indica si cadena termina con otra ----");
        System.out.println("\nCadena 1: ");
        cad1 = scan.nextLine();
        System.out.println("\nCadena 2: ");
        cad2 = scan.nextLine();
        if(s.subcadenaFinal(cad1,cad2)) {
            System.out.println("\nCadena 1 SI termina con cadena 2");
        }
        else {
            System.out.println("\nCadena 1 NO termina con cadena 2");
        }
        
        //3 programa que comprueba si una cadena leída por teclado comienza por una subcadena introducida por teclado.
        System.out.println("\n----3 Indica si cadena inicia con otra ----");
        System.out.println("\nCadena 1: ");
        cad1 = scan.nextLine();
        System.out.println("\nCadena 2: ");
        cad2 = scan.nextLine();
        if(s.subcadenaInicial(cad1,cad2)) {
            System.out.println("\nCadena 1 SI comienza con cadena 2");
        }
        else {
            System.out.println("\nCadena 1 NO comienza con cadena 2");
        }
        
        //4 Pide una cadena y un carácter por teclado (valida que sea un carácter)
        //y muestra cuantas veces aparece el carácter en la cadena
        System.out.println("\n----4 Muestra cuantas veces aparece un caracter en una cadena ----");
        System.out.println("\nCadena: ");
        cad1 = scan.nextLine();
        do{
            System.out.println("Caracter: ");
            cad2 = scan.nextLine();
            aux = cad2.toCharArray();
            if(cad2.length()!=1 || !Character.isLetter(aux[0])) {
                System.out.println("\nNo introdujo un caracter, intente de nuevo");
            }
        }while(cad2.length()!=1 || !Character.isLetter(aux[0]));
        System.out.println("Caracter '"+cad2+"' aparece " + s.cantCaracter(cad1, aux[0]) + " veces");
        
        //5 realiza un programa que cuente cuantas palabras tiene una frase
        //de entrada.
        System.out.println("\n----5 Cuenta cuantas palabras tiene una frase ----");
        System.out.println("Introduzca frase: ");
        cad1 = scan.nextLine();
        System.out.println("La frase introducida tiene " + s.cantPalabras(cad1) + " palabras");
        
        //6 cadena con un nombre y apellidos, realizar un programa que muestre las iniciales en mayúsculas.
        System.out.println("\n----6 Muestra iniciales de un nombre ----");
        System.out.println("Introduzca nombre");
        cad1 = scan.nextLine();
        System.out.println("Las iniciales de ese nombre son: " + s.iniciales(cad1));
        
        //7 programa que dada una cadena de caracteres por caracteres, genere otra cadena resultado de invertir la primera. 
        System.out.println("\n----7 Invierte una cadena de caracteres ----");
        System.out.println("Cadena a invertir: ");
        cad1 = scan.nextLine();
        System.out.println("Cadena invertida: \n" + s.invertir(cad1));
        
        //8 Pide una cadena y dos caracteres por teclado (valida que sea un carácter), 
        //sustituye la aparición del primer carácter en la cadena por el segundo carácter.
        System.out.println("\n----8 Sustituye los caracteres de una cadena por otros ----");
        System.out.println("Cadena a modificar: ");
        cad1 = scan.nextLine();
        do{
            System.out.println("Caracter a reemplazar: ");
            cad2 = scan.nextLine();
            aux = cad2.toCharArray();
            if(cad2.length()!=1 || !Character.isLetter(aux[0])) {
                System.out.println("\nNo introdujo un caracter, intente de nuevo");
            }
        }while(cad2.length()!=1 || !Character.isLetter(aux[0]));
        
        do{
            System.out.println("Caracter por el cual reemplazarlo: ");
            cad3 = scan.nextLine();
            aux = cad3.toCharArray();
            if(cad3.length()!=1 || !Character.isLetter(aux[0])) {
                System.out.println("\nNo introdujo un caracter, intente de nuevo");
            }
        }while(cad3.length()!=1 || !Character.isLetter(aux[0]));
        
        System.out.println("Cadena modificada:\n" + s.sustitCaracter(cad1, cad2.charAt(0), cad3.charAt(0)));
        
        //9 Realizar un programa que lea una cadena por teclado
        //y convierta las mayúsculas a minúsculas y viceversa.
        System.out.println("\n----9 Invierte mayusculas y minusculas ----");
        System.out.println("Cadena: ");
        cad1 = scan.nextLine();
        System.out.println("Cadena con mayusculas y  minusculas invertidas: \n" + s.invierteCase(cad1));
        
        
        //10 Dada dos cadenas, checar si la primera contiene a la segunda.
        System.out.println("\n----10 Indica si cadena es contenida en otra ----");
        System.out.println("Cadena 1: ");
        cad1 = scan.nextLine();
        System.out.println("Cadena 2: ");
        cad2 = scan.nextLine();
        if(s.subcadena(cad1, cad2)){
            System.out.println("Cadena 1 SI contiene a cadena 2");
        }
        else {
            System.out.println("Cadena 1 NO contiene a cadena 2");
        }
        
        //11 Introducir una cadena de caracteres e indicar si es un palíndromo.
        System.out.println("\n----11 Halla si palabra es palindroma ----");
        System.out.println("Cadena 1: ");
        cad1 = scan.nextLine();
        if(s.esPalindromo(cad1)) {
            System.out.println("La cadena SI es palindromo");
        }
        else {
            System.out.println("La cadena NO es palindromo");
        }
    }
    
}
