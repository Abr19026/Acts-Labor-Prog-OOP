/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author Funxb
 */
public class Automovil extends Transporte implements IAvanzar, IFrenar{
    private String marca;
    private String modelo;
    private String color;
    private String precio;
    
    private boolean encendido;
    
    void vuelta(String direccion) {
        if(direccion == "derecha") {
            System.out.println("Volteando a la derecha");
        }
        else if(direccion == "izquierda"){
            System.out.println("Volteando a la izquierda");
        }
    }
 
    void imprimir() {
        System.out.println("Marca: " + marca + "\nModelo: " + modelo + "\nColor: " + color + "\nPrecio: $" + precio);
    }
    
    @Override
    void encender() {
        this.encendido = true;
        System.out.println(marca + " " + modelo + " encendido");
    }
    
    Automovil(String marca, String modelo, String color, String precio) {
        this.encendido = false;
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    @Override
    public String avanzar(int gasolina) {
        return "Auto avanza " + (gasolina*12) + " kilometros";
    }

    @Override
    public void frenar() {
        System.out.println("Frenando carro");
    }
}
