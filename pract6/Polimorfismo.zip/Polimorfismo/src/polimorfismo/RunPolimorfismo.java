/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Funxb
 */
public class RunPolimorfismo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner Scan = new Scanner(System.in);

        String saux1, saux2, saux3, saux4;
        int auxint;
        Automovil caux;
                
        ArrayList<Automovil> al = new ArrayList<>(10);
        
        //Lectura de datos de cada carro
        for(int i=0;i<10;i++) {
            System.out.print("\n\nCarro " + (i+1) + "\nMarca: ");
            saux1 = Scan.nextLine();
            System.out.print("\nModelo: ");
            saux2 = Scan.nextLine();
            System.out.print("\nColor: ");
            saux3 = Scan.nextLine();
            System.out.print("\nPrecio: $ ");
            saux4 = Scan.nextLine();
            caux = new Automovil(saux1, saux2, saux3, saux4);
            al.add(caux);
        }
        
        for(Automovil a : al) {
            a.imprimir();
            a.encender(); 
            a.avanzar();
            a.vuelta("izquierda");
        }
        
        System.out.println("\n  Parte 2");
        //PARTE 2
        ArrayList<Transporte> otro = new ArrayList<>(10);
        Transporte tra;
        
        for(int i=0;i<10;i++) {
            if(i<5) {
                System.out.print("\n\nCarro " + (i%5+1) + "\nMarca: ");
                saux1 = Scan.nextLine();
                System.out.print("\nModelo: ");
                saux2 = Scan.nextLine();
                System.out.print("\nColor: ");
                saux3 = Scan.nextLine();
                System.out.print("\nPrecio: $ ");
                saux4 = Scan.nextLine();
                tra = new Automovil(saux1, saux2, saux3, saux4);
            }
            else {
                System.out.print("\n\nTren " + (i%5+1) + "\nMarca: ");
                saux1 = Scan.nextLine();
                System.out.print("\nModelo: ");
                saux2 = Scan.nextLine();
                System.out.print("\nCantidad de vagones: ");
                auxint = Scan.nextInt();
                Scan.nextLine();
                tra = new Tren(saux1, saux2, auxint);
            }
            otro.add(tra);
        }
        
        for(Transporte a : otro) {
            a.encender(); 
            a.avanzar();
        }
        
        
        //PARTE 3
        System.out.print("\n\nCarro " + "\nMarca: ");
        saux1 = Scan.nextLine();
        System.out.print("\nModelo: ");
        saux2 = Scan.nextLine();
        System.out.print("\nColor: ");
        saux3 = Scan.nextLine();
        System.out.print("\nPrecio: $ ");
        saux4 = Scan.nextLine();
        IAvanzar avanzable = new Automovil(saux1, saux2, saux3, saux4);
        
        System.out.println(avanzable.avanzar(45));
        
    }
    
}
