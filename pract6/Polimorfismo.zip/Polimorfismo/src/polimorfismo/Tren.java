/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author Funxb
 */
public class Tren extends Transporte implements IAvanzar, IFrenar{
    private String marca;
    private String modelo;
    private int vagones;
    private boolean encendido;
    
    Tren(String marca, String modelo, int vagones) {
        this.marca = marca;
        this.modelo = modelo;
        this.vagones = vagones;
        this.encendido = false;
    }
    
    void imprimir() {
        System.out.println("Marca: " + marca + "\nModelo: " + modelo + "\nVagones: " + vagones);
    }
    
    @Override
    void encender() {
        encendido = true;
        System.out.println("Tren " + marca + " " + modelo + " encendido");
    }

    @Override
    public String avanzar(int gasolina) {
        return "Tren avanza " + (gasolina*40) + " kilometros";
    }

    @Override
    public void frenar() {
        System.out.println("Frenando tren");
    }
    
}
